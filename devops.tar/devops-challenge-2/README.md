# devops-challenge-2
devops-challenge-2

to run just docker compose build and up <br>
curl or hit the url localhost:8080 to activate some logs note only error urls send bytes in body 
```
localhost:8080  //ngnix instance
localhost:5601  //kibana
localhost:9200  //elasticsearch
localhost:9600  //logstash

```
to import the dashboard and objects created go to http://localhost:5601/app/kibana#/management/kibana/objects then import the export.ndjson file
